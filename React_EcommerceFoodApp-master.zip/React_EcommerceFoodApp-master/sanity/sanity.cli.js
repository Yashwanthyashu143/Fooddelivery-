import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'l0w01o15',
    dataset: 'production'
  }
})
