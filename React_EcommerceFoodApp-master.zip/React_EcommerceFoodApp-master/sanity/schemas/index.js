import pizza from "./pizza"
import order from "./order"
export const schemaTypes = [pizza,order]
